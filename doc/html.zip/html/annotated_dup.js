var annotated_dup =
[
    [ "GUIcalc", "namespace_g_u_icalc.html", "namespace_g_u_icalc" ],
    [ "RST", "namespace_r_s_t.html", "namespace_r_s_t" ],
    [ "Debug", "class_debug.html", "class_debug" ],
    [ "FeatureSelect", "class_feature_select.html", "class_feature_select" ],
    [ "Program", "class_program.html", "class_program" ],
    [ "Test", "class_test.html", "class_test" ],
    [ "TestGUI", "class_test_g_u_i.html", "class_test_g_u_i" ]
];