var dir_f3671eb1afd460317e20315ff41fe127 =
[
    [ "Draw.java", "_draw_8java.html", [
      [ "Draw", "class_g_u_icalc_1_1_draw.html", "class_g_u_icalc_1_1_draw" ]
    ] ],
    [ "Predict.java", "_predict_8java.html", [
      [ "Predict", "class_g_u_icalc_1_1_predict.html", "class_g_u_icalc_1_1_predict" ]
    ] ],
    [ "Train.java", "_train_8java.html", [
      [ "Train", "class_g_u_icalc_1_1_train.html", "class_g_u_icalc_1_1_train" ]
    ] ]
];