var class_g_u_icalc_1_1_train =
[
    [ "Train", "class_g_u_icalc_1_1_train.html#aa4ec93ba79eb830a88c6b61f9494aa30", null ],
    [ "Train", "class_g_u_icalc_1_1_train.html#adeb9f469170ac9c60f45b0bf843f7a88", null ],
    [ "doInBackground", "class_g_u_icalc_1_1_train.html#ab2a7eea54c688a4e66547bd47b1bf7f2", null ],
    [ "process", "class_g_u_icalc_1_1_train.html#a8fbfc774c84821c1da608f708e2ce210", null ],
    [ "matrixPath", "class_g_u_icalc_1_1_train.html#a8307c6cc42fb0bb50394fa94d9db965e", null ],
    [ "model", "class_g_u_icalc_1_1_train.html#a59a726eb2db9ab07c01492691e9647eb", null ],
    [ "textArea", "class_g_u_icalc_1_1_train.html#a2eb348cede3a8ea9c82e79837e0c37c2", null ],
    [ "trainFolders", "class_g_u_icalc_1_1_train.html#a82adb10f1c439281f97daee4e3113a17", null ]
];