var class_r_s_t_1_1_usefull =
[
    [ "Usefull", "class_r_s_t_1_1_usefull.html#a2eac27dff12ff29c8add0e318e86afe7", null ],
    [ "action2label", "class_r_s_t_1_1_usefull.html#a4a0e47ff1d36da7565ee03ed3d56b436", null ],
    [ "buildgold", "class_r_s_t_1_1_usefull.html#a9b81f99d5c1cc70446b117e71394e40d", null ],
    [ "generate_rawdata", "class_r_s_t_1_1_usefull.html#afbb5a1fef6b72097778c2ee573138138", null ],
    [ "print", "class_r_s_t_1_1_usefull.html#afe8d4a1c130fd2cfec866245e8b5b9c6", null ],
    [ "print", "class_r_s_t_1_1_usefull.html#a1366c3d05f1191a7b0a29ffda93d5cb2", null ],
    [ "printListList", "class_r_s_t_1_1_usefull.html#a08450c90fb1a148e20e92a4aed1a6d15", null ],
    [ "serialize", "class_r_s_t_1_1_usefull.html#aadb5f9c37d850427928ef75b7e499dd6", null ]
];