var class_r_s_t_1_1_test_data =
[
    [ "getedus", "class_r_s_t_1_1_test_data.html#ac38f129c7c1965cb7e66c1439e63d06f", null ],
    [ "edus", "class_r_s_t_1_1_test_data.html#a18de31a888970552af6d8513d5775ea6", null ],
    [ "id", "class_r_s_t_1_1_test_data.html#ab2898226ef67647b88846dc07bd4db20", null ],
    [ "sentenceID", "class_r_s_t_1_1_test_data.html#a44dd316f7069ae48029aee5e0655c993", null ]
];