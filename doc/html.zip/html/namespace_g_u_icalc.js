var namespace_g_u_icalc =
[
    [ "Draw", "class_g_u_icalc_1_1_draw.html", "class_g_u_icalc_1_1_draw" ],
    [ "Predict", "class_g_u_icalc_1_1_predict.html", "class_g_u_icalc_1_1_predict" ],
    [ "Train", "class_g_u_icalc_1_1_train.html", "class_g_u_icalc_1_1_train" ]
];