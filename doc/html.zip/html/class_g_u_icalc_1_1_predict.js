var class_g_u_icalc_1_1_predict =
[
    [ "Predict", "class_g_u_icalc_1_1_predict.html#ad8da6abb3e5a3c4363d70eac4c17641e", null ],
    [ "Predict", "class_g_u_icalc_1_1_predict.html#a41bcc2015b5935d2fb2f1a3b66b4e70e", null ],
    [ "doInBackground", "class_g_u_icalc_1_1_predict.html#a6bf33faa34d80094d26e9baafdbc3398", null ],
    [ "process", "class_g_u_icalc_1_1_predict.html#a9b3190678c42cdf4d6daf0e80903a01c", null ],
    [ "draw", "class_g_u_icalc_1_1_predict.html#a3c88d6d0625f9d8e7e655ab36d0e6b60", null ],
    [ "goldFolders", "class_g_u_icalc_1_1_predict.html#a687c2526048c36dee404d47656b39cd3", null ],
    [ "model", "class_g_u_icalc_1_1_predict.html#a6ff1f180c8f33edf9bea258c060e94ca", null ],
    [ "modelname", "class_g_u_icalc_1_1_predict.html#aac29955cab903e6166083824b2578d9e", null ],
    [ "predictFolders", "class_g_u_icalc_1_1_predict.html#aa39cd0b67f6624a5e3f5f6becd29b8e9", null ],
    [ "predtrees", "class_g_u_icalc_1_1_predict.html#a19c40518f6522902e8407da37f470b05", null ],
    [ "textArea", "class_g_u_icalc_1_1_predict.html#ae15832876a03df8f67f3726105dfee0b", null ]
];