var class_r_s_t_1_1_token =
[
    [ "Token", "class_r_s_t_1_1_token.html#a2b691cc525fa3fd885ad8333e96fe172", null ],
    [ "eduID", "class_r_s_t_1_1_token.html#a1e9d0a3013bfa10300a944f1eb805cd8", null ],
    [ "lemma", "class_r_s_t_1_1_token.html#a840cf005efc3f74f80bc0b0542148e8d", null ],
    [ "morph", "class_r_s_t_1_1_token.html#ae3139d5f59f91e498f7507cd80fc6a82", null ],
    [ "pos", "class_r_s_t_1_1_token.html#ac60d562b8b2ddd79214ee89157a2c45b", null ],
    [ "sentenceID", "class_r_s_t_1_1_token.html#a6e7565f42694642bde397cbd2ca405b1", null ],
    [ "tokenID", "class_r_s_t_1_1_token.html#a3041b16acb2d694bfde53c7804636ba1", null ],
    [ "word", "class_r_s_t_1_1_token.html#a8d3217892ccf3fdb05f1fb6718e0c477", null ]
];