var class_r_s_t_1_1_features =
[
    [ "Features", "class_r_s_t_1_1_features.html#a7d1e5c43ed04f6b516216ace532c8115", null ],
    [ "addfeature", "class_r_s_t_1_1_features.html#a83f1d46767897bb6daa9660726d8aa44", null ],
    [ "addfeature", "class_r_s_t_1_1_features.html#a2f6d7db4b848067ce7d5fd633de292a2", null ],
    [ "addfeature", "class_r_s_t_1_1_features.html#a2406eae2818e61e8312f947a89408d3a", null ],
    [ "edu_features", "class_r_s_t_1_1_features.html#a21885856ed2a7292e6e710da8257e7cf", null ],
    [ "getfeatures", "class_r_s_t_1_1_features.html#a548a35caf2a6450bf9cdab3b2781f5fe", null ],
    [ "status_features", "class_r_s_t_1_1_features.html#ad8319b91a9af5001063c92a18622d1c0", null ],
    [ "structural_features", "class_r_s_t_1_1_features.html#a20a65f1b361986f29fef0653f6fcd94f", null ],
    [ "distributional_feature", "class_r_s_t_1_1_features.html#a7070f6283e53a2c71245ae0249048418", null ],
    [ "edu_feature", "class_r_s_t_1_1_features.html#a938b17972bb529f119f436bebb195566", null ],
    [ "edulen1", "class_r_s_t_1_1_features.html#a7c8a7100b778443a5e1a3040cbebbbde", null ],
    [ "edulen2", "class_r_s_t_1_1_features.html#ad0a21bfac4284ce56976d359bfba2aa1", null ],
    [ "edusize", "class_r_s_t_1_1_features.html#a20dd2862ee20ae532a7bbf8d93570d7f", null ],
    [ "firstspan", "class_r_s_t_1_1_features.html#aeb410e5291e4914dceb33780f6179469", null ],
    [ "status_feature", "class_r_s_t_1_1_features.html#ae9c81736fda8255ced5c08586d95f81b", null ],
    [ "structural_feature", "class_r_s_t_1_1_features.html#aac5684ed3618ac4585b605985fb39757", null ],
    [ "top1span", "class_r_s_t_1_1_features.html#a7b41f3c4c6c5f1d74e7da2ca3a092382", null ],
    [ "top2span", "class_r_s_t_1_1_features.html#a1f49a2192f0b6962461c861ded618ade", null ]
];