var class_feature_select =
[
    [ "FeatureSelect", "class_feature_select.html#ac3578b02ade8f02b3b70c181af3f618c", null ],
    [ "frequency", "class_feature_select.html#a6df06f04a69aae3b9b9bbe06069e13c7", null ],
    [ "rank", "class_feature_select.html#ac503d5dc4042c402397df5588e561243", null ],
    [ "select", "class_feature_select.html#a3d92e6f80239ba1a41f7467d8322a760", null ],
    [ "method", "class_feature_select.html#af85ff0f7788f9722315a831b8344849f", null ],
    [ "topn", "class_feature_select.html#a043bb6300744de0b35a60827a1e2fb02", null ]
];