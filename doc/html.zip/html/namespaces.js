var namespaces =
[
    [ "GUIcalc", "namespace_g_u_icalc.html", null ],
    [ "RST", "namespace_r_s_t.html", null ]
];