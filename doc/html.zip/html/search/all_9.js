var searchData=
[
  ['main',['main',['../class_debug.html#a1e9a833a5aa6bca8b64da06cb303f169',1,'Debug.main()'],['../class_program.html#acce23ed8021e15e6d1b99a195c94c43e',1,'Program.main()'],['../class_test.html#ad91b01698e99c4a022d21159dd694250',1,'Test.main()'],['../class_test_g_u_i.html#aaeb23e35c887ab60676cdbe9b19293ad',1,'TestGUI.main()']]],
  ['matrixpath',['matrixPath',['../class_g_u_icalc_1_1_train.html#a8307c6cc42fb0bb50394fa94d9db965e',1,'GUIcalc::Train']]],
  ['matrixsize',['matrixsize',['../class_r_s_t_1_1_s_v_m.html#a510d00dab5118e87a9cdb5edcd10f91e',1,'RST::SVM']]],
  ['method',['method',['../class_feature_select.html#af85ff0f7788f9722315a831b8344849f',1,'FeatureSelect']]],
  ['model',['model',['../class_g_u_icalc_1_1_predict.html#a6ff1f180c8f33edf9bea258c060e94ca',1,'GUIcalc.Predict.model()'],['../class_g_u_icalc_1_1_train.html#a59a726eb2db9ab07c01492691e9647eb',1,'GUIcalc.Train.model()'],['../class_r_s_t_1_1_s_v_m.html#a8cfea8bf3c479ea6b6b29f5b2ae49751',1,'RST.SVM.model()']]],
  ['modelname',['modelname',['../class_g_u_icalc_1_1_predict.html#aac29955cab903e6166083824b2578d9e',1,'GUIcalc.Predict.modelname()'],['../class_program.html#a45bcaa92a303208de687b55406798946',1,'Program.modelname()']]],
  ['morph',['morph',['../class_r_s_t_1_1_token.html#ae3139d5f59f91e498f7507cd80fc6a82',1,'RST::Token']]]
];
