var searchData=
[
  ['qmatrix',['QMatrix',['../classlibsvm_1_1_q_matrix.html',1,'libsvm']]]
];
