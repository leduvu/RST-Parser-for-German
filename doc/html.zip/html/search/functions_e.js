var searchData=
[
  ['token',['Token',['../class_r_s_t_1_1_token.html#a2b691cc525fa3fd885ad8333e96fe172',1,'RST::Token']]],
  ['train',['train',['../class_r_s_t_1_1_s_v_m.html#a175fa794d975b1fd6bac0853b4667d45',1,'RST.SVM.train()'],['../class_g_u_icalc_1_1_train.html#aa4ec93ba79eb830a88c6b61f9494aa30',1,'GUIcalc.Train.Train(List&lt; File &gt; trainFolders, JTextArea textArea)'],['../class_g_u_icalc_1_1_train.html#adeb9f469170ac9c60f45b0bf843f7a88',1,'GUIcalc.Train.Train()']]]
];
