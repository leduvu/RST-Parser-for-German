var searchData=
[
  ['loss_2ejava',['loss.java',['../loss_8java.html',1,'']]]
];
