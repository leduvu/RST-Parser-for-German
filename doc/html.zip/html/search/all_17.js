var searchData=
[
  ['y',['y',['../classlibsvm_1_1_solver.html#a5a84f827bd36b01f442dbe91808e965a',1,'libsvm.Solver.y()'],['../classlibsvm_1_1_s_v_c___q.html#aa7bb4cca21ff7ad5b55334ea31ebd23b',1,'libsvm.SVC_Q.y()'],['../classlibsvm_1_1svm__problem.html#affe2ee311a71216facc4f22c9ebae0d3',1,'libsvm.svm_problem.y()']]]
];
