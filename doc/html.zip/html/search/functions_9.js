var searchData=
[
  ['node',['Node',['../class_r_s_t_1_1_node.html#a5d10a1fa1ba30a65f6a3d6c75c662660',1,'RST.Node.Node(int id, int xmlID, int pnodeID, String relation, String text, Set&lt; Integer &gt; sentenceID)'],['../class_r_s_t_1_1_node.html#abc6e7b8aaf470b83dcaf5b3fe96147de',1,'RST.Node.Node(int id, int xmlID, int pnodeID, String relation)'],['../class_r_s_t_1_1_node.html#a4a6100061ad59b8be327a2951c534ee2',1,'RST.Node.Node(int id, String relation, String prop)'],['../class_r_s_t_1_1_node.html#a31949632f7f0f3509c4760f9d5741c54',1,'RST.Node.Node()']]]
];
