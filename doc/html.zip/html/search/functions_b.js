var searchData=
[
  ['predict',['Predict',['../class_g_u_icalc_1_1_predict.html#ad8da6abb3e5a3c4363d70eac4c17641e',1,'GUIcalc.Predict.Predict(List&lt; File &gt; predictFolders, List&lt; File &gt; goldFolders, SVM model, JTextArea textArea, String modelname)'],['../class_g_u_icalc_1_1_predict.html#a41bcc2015b5935d2fb2f1a3b66b4e70e',1,'GUIcalc.Predict.Predict()'],['../class_r_s_t_1_1_s_v_m.html#ae5f0a5aabdda0af935f4c23510fe6dd9',1,'RST.SVM.predict()']]],
  ['print',['print',['../class_r_s_t_1_1_usefull.html#afe8d4a1c130fd2cfec866245e8b5b9c6',1,'RST.Usefull.print(List&lt; Node &gt; nodeList)'],['../class_r_s_t_1_1_usefull.html#a1366c3d05f1191a7b0a29ffda93d5cb2',1,'RST.Usefull.print(Node root, String title)']]],
  ['printlistlist',['printListList',['../class_r_s_t_1_1_usefull.html#a08450c90fb1a148e20e92a4aed1a6d15',1,'RST::Usefull']]],
  ['process',['process',['../class_g_u_icalc_1_1_draw.html#a3a4894e2431853c308156ae8a5630ad5',1,'GUIcalc.Draw.process()'],['../class_g_u_icalc_1_1_predict.html#a9b3190678c42cdf4d6daf0e80903a01c',1,'GUIcalc.Predict.process()'],['../class_g_u_icalc_1_1_train.html#a8fbfc774c84821c1da608f708e2ce210',1,'GUIcalc.Train.process()']]]
];
