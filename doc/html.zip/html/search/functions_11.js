var searchData=
[
  ['update_5falpha_5fstatus',['update_alpha_status',['../classlibsvm_1_1_solver.html#ad197d2c6113be5be23b9960c9a4f3f53',1,'libsvm::Solver']]],
  ['usefull',['Usefull',['../class_r_s_t_1_1_usefull.html#a2eac27dff12ff29c8add0e318e86afe7',1,'RST::Usefull']]]
];
