var searchData=
[
  ['vocab',['vocab',['../class_r_s_t_1_1_data.html#ab542963abc5e004e7117fded8216b1aa',1,'RST::Data']]],
  ['vocabid',['vocabID',['../class_r_s_t_1_1_data.html#a0d5d7d010ca6dc6c93b9b8d07bab7f79',1,'RST::Data']]]
];
