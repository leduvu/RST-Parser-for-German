var searchData=
[
  ['gold_5fb_5fborder',['GOLD_B_BORDER',['../class_program.html#a59cb633ea82b16ff7ee7cddeec645451',1,'Program']]],
  ['goldfolders',['goldFolders',['../class_g_u_icalc_1_1_predict.html#a687c2526048c36dee404d47656b39cd3',1,'GUIcalc.Predict.goldFolders()'],['../class_program.html#a5bf7879e6d26c45c7429bf9abbb687e5',1,'Program.goldFolders()']]]
];
