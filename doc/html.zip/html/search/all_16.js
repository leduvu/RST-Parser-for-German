var searchData=
[
  ['x',['x',['../classlibsvm_1_1_kernel.html#a8e9853d0012a0e1b7dac36ca583e8a39',1,'libsvm.Kernel.x()'],['../classlibsvm_1_1svm__problem.html#ab551d9238bf36c4ba83c018569b09fbb',1,'libsvm.svm_problem.x()']]],
  ['x_5fsquare',['x_square',['../classlibsvm_1_1_kernel.html#aae1e0a47ea69f47a09efbfd3ac1bf327',1,'libsvm::Kernel']]],
  ['xmlid',['xmlID',['../class_r_s_t_1_1_node.html#a9708642dc15af563166479f3a547fd31',1,'RST::Node']]]
];
