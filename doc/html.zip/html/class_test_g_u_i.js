var class_test_g_u_i =
[
    [ "build", "class_test_g_u_i.html#a6d4b9e595f9af22b5efb54f032c04558", null ],
    [ "main", "class_test_g_u_i.html#aaeb23e35c887ab60676cdbe9b19293ad", null ],
    [ "serialVersionUID", "class_test_g_u_i.html#a2e21146ef472e1a955f4e6b3a7432c66", null ]
];